<?php
namespace App\Services\Business;

use App\Models\UserModel;
use App\Models\CustomerModel;
use App\Services\Data\SecurityDAO;
use App\Services\Data\CustomerDAO;
use App\Services\Data\OrderDAO;
use App\Services\Data\Utility\DBConnect;

class SecurityService
{
    // define properties
    private $verifyCred;
    
//     public function __construct()
//     {
        
//     }
    
    public function login(UserModel $credentials)
    {
        // Instantiate the data access layer
        $this->verifyCred = new SecurityDAO();
        // return true or false by passing credentials
        // to the object
        return $this->verifyCred->FindByUserName($credentials);
    }

    // method to pass the data to the data access layer
    public function addCustomer(CustomerModel $customerData)
    {
        // Instantiate the Data Access Layer
        $this->addNewCustomer = new CustomerDAO();

        // return true or false by passing the insert result
        return $this->addNewCustomer->addCustomer($customerData);
    }

    // Manage order data
    public function addOrder(string $product, int $customerID)
    {
        // Instantiate the Data Access Layer
        $this->addNewOrder = new OrderDAO();

        // return true or false by passing the insert result
        return $this->addNewOrder->addOrder($product, $customerID);
    }

    // Manage Acid
    public function addAllinformation(string $product, int $customerID, CustomerModel $customerData)
    {
        // Cretae a connection tp the database
        // create an instance of the class
        $conn = new DBConnect("activity3");
        // call the method to create a connection
        $dbObj = $conn->getDbConnect();

        // first we turn off autocommit
        $conn->setDbAutocommitFalse();
        // Begin transaction
        $conn->beginTransaction();

        // Instantiate the Data Access Layer
        $this->addNewCustomer = new CustomerDAO($dbObj);
        // Get the next Customer Id
        $customerID = $this->addNewCustomer->getNextID();

        // add the customer data
        $isSuccessful = $this->addNewCustomer->addCustomer($customerData);

        // Instantiate the Data Access Layer
        $this->addNewOrder = new orderDAO($dbObj);

        // Add the product to the orderData
        $isSuccessfulOrder = $this->addNewOrder->addOrder($product, $customerID);

        if ($isSuccessful && $isSuccessfulOrder) {
            $conn->commitTransaction();
            return true;
        } else {
            $conn->rollbackTransaction();
            return false;
        }
    }
}
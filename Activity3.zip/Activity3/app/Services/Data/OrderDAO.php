<?php
namespace App\Services\Data;

//use App\Models\CustomerModel;
use App\Services\Data\Utility\DBConnect;
use Carbon\Exceptions\Exception;

class OrderDAO
{
    //define connection
    private $conn;
    //private $dbname = "activity3";
    private $dbQuery;
    private $port = "3306";
    private $connection;
    private $dbObj;
    
    //constructor that creates a coonnection with the database
    public function __construct($dbObj)
    {
        $this->dbObj = $dbObj;
    }
    
    //method to add customer to database
    function addOrder(string $product, int $customerID)
    {
        try {
            // define the query and DB for the credentials
            $this->dbQuery = "INSERT INTO 'order'
                               (Product, CustomerID)
                                VALUES
                                ('" . $product . "', " . $customerID . ")";
                                
            
          //  $result = mysqli_query($this->conn, $this->dbQuery);
            //OOP style
            if ($this->dbObj->query($this->dbQuery))
            {
                //$this->conn->closeDbConnect();
                return true;
            }
            else 
            {
               // $this->conn->closeDbConnect();
                return false;
            }
        } catch (Exception $e) {
            $e->getMessage();
        }
    }
    
}




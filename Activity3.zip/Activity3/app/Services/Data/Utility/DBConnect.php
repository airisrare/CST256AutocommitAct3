<?php
namespace App\Services\Data\Utility;

// use App\Models\CustomerModel;
// use Carbon\Exceptions\Exception;
use mysqli;

class DBConnect
{
    //define connection
    private $conn;
    private $servername;
    private $username ;
    private $password;
    private $dbname;
   
    
    //constructor that creates a coonnection with the database
    public function __construct(string $dbname)
    {
        //initialize the properties 
        $this->dbname = $dbname;
        $this->servername = "localhost";
        $this->username = "root";
        $this->password = "root";
        $this->port = "3306";
        
        
        
    }
    
    
    public function getDbConnect()
    {
        //OOP style programming
        $this->conn = new mysqli($this->servername, $this->username, $this->password ,$this->dbname, $this->port);
        
        //create a connection to the database
        //procedural style programming
        //$this->conn = mysqli_connect($this->servername, $this->username, $this->password ,$this->dbname, $this->port);
        //make sure to test the connection to see if there are any errors
        
        //Error checking
        if($this->conn->connect_errno)
        {
            echo "Failed to connect to mysql" . $this->conn->connect_error;
            exit();
        }
        return($this->conn);
        
    }
    
   /*
    * Close the connection
    */
    
    public function closeDbConnect()
    {
        //OOP style 
        $this->conn->close();
        //Procedural style
        //mysqli_close($this->conn);
    }
    
    /*
     * Turn on AutoCommit
     */
    Public function setDbAutocommitTrue()
    {
        //Turn Autocommit on
        $this->conn->autocommit(TRUE);
    }
    
    //Turn off autocommit
    Public function setDbAutocommitFalse()
    {
        //Turn Autocommit on
        $this->conn->autocommit(FALSE);
    }
    
    /*
     * Begin a Transaction
     * 
     */
    public function beginTransaction()
    {
        $this->conn->begin_transaction();
    }
    
    /*
     * Commit the transaction
     */
    
    public function commitTransaction()
    {
        $this->conn->commit();
    }
    
    public function rollbackTransaction()
    {
        $this->conn->rollback();
    }
}




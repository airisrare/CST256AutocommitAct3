<?php
namespace App\Services\Data;

use App\Models\CustomerModel;
use App\Services\Data\Utility\DBConnect;
use Carbon\Exceptions\Exception;

class CustomerDAO
{
    //define connection
    private $conn;
    //private $dbname = "activity3";
    private $dbQuery;
    private $port = "3306";
    private $connection;
   // private $dbObj;
    
    //constructor that creates a coonnection with the database
    public function __construct($dbObj)
    {
        //$this->$dbObj = $dbObj;
        $this->conn = new DBConnect("activity3");
        $this->connection = $this->conn->getDbConnect();
    }
    
    //method to add customer to database
    function addCustomer(CustomerModel $customerData)
    {
        try {
            // define the query and DB for the credentials
            $this->dbQuery = "INSERT INTO customer
                               (FirstName, LastName)
                                VALUES
                                ('{$customerData->getFirstName()}','{$customerData->getLastName()}')";
                                
            
          //  $result = mysqli_query($this->conn, $this->dbQuery);
            
            if ($this->connection->query($this->dbQuery))
            {
                //$this->conn->closeDbConnect();
                return true;
            }
            else 
            {
                //$this->conn->closeDbConnect();
                return false;
            }
        } catch (Exception $e) {
            $e->getMessage();
        }
    }
    


//ACID
//Get the next id for the primary key to put in the foreign key
public function getNextID()
{
    try{
        //define the query to get the next ID
        $this->dbQuery = "SELECT CustomerID
                           FROM customer
                            ORDER BY CustomerID DESC LIMIT 0,1";
        $result = $this->connection->query($this->dbQuery);
        while($row = mysqli_fetch_array($result))
        {
            //Point to the next row that has not been commited yet
            return $row['CustomerID'] + 1;
        }
        
    }
    catch(Exception $e)
    {
        echo $e->getMessage();
    }
}



}

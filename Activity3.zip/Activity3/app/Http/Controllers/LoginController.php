<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\UserModel;
use App\Services\Business\SecurityService;

class LoginController extends Controller
{
    

    
        public function index(Request $request)
        {
            //test the form 
            $this->validateForm($request);
            
            //this is from the next step d
            //Create a UserModel with username and password
            
            $credentials = new UserModel($request->get('username'),$request->get('password'));
            
            //instantiate the business Logic Layer 
            $serviceLogin = new SecurityService();
            
            //pass credentials to the business layer
            $isValid = $serviceLogin->login($credentials);
            
            //Determine which view to display
            if($isValid)
            {
                return view('loginPassed');
            }
            else{
                return view('LoginFailed');
            }
                
//             {
//                 $data = [
//                     'model' => $credentials
//                 ];
//                 //
//                 return view('loginPassed2')->with($data);
//             }
//             else
//             {
//                 return view("loginFailed");
//             }
            
            
        }
        //validation function added for Activity3
        public function validateForm(Request $request)
        {
            //Set up data validation for our login form
            $rules = ['username'=>'Required|Bewtween:4,10|Alpha',
                'password'=>'Required|Between:4,10'];
            //Run data validation rules
            $this->validate($request, $rules);
        }
        

}
            

            
            
            
            
//             $formValues = $request->all();
//             $userName = $request->get('username');
            
//             // Usage of path method
//             $path = $request->path();
//             echo 'Path Method: '.$path;
//             echo '<br>';
            
//             // Usage of is method
//             $method = $request->isMethod('get') ? "GET" : "POST";
//             echo 'GET or POST Method: '.$method;
//             echo '<br>';
            
//             // Usage of url method
//             $url = $request->url();
//             echo 'URL method: '.$url;
//             echo '<br>';
            
//             $firstName = $request->input('firstname');
//             $lastName = $request->input('lastname');
//             echo "Your name is: " . $firstName . " " . $lastName . "<br>";
           


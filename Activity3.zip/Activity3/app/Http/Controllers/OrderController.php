<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Services\Business\SecurityService;
use App\Models\CustomerModel;
class OrderController extends Controller
{
   
        public function index(Request $request)
        {
            //put customer data in a model
            $customerData = new CustomerModel(request()->get('firstName'), request()->get('lastName'));
            
            
            //not using a model this time 
            $product = request()->get('product');
            //this is more efficient because it is not calling a method
            $customerID = $request->input('customerID');
            
            //instantiate the business Logic Layer 
            $serviceCustomer = new SecurityService();
            
            //pass orderData to the business layer
                $isValid = $serviceCustomer->addAllinformation($product, $customerID, $customerData);  
            
            
            //Determine which view to display
            if($isValid)
            {
                echo("Order Data committed successfully ");
             
            }
            else{
                echo("Order Data was rolled back");
            }
                return view('order');
                

            
        }
        //validation function added for Activity3
        public function validateForm(Request $request)
        {
            //Set up data validation for our login form
            $rules = ['username' => 'Required | Bewtween: 4, 10 | Alpha' ,
                'password' => 'Required | Between: 4, 10'];
            //Run data validation rules
            $this->validate($request, $rules);
        }
        

}
            

            
            
            
            
//             $formValues = $request->all();
//             $userName = $request->get('username');
            
//             // Usage of path method
//             $path = $request->path();
//             echo 'Path Method: '.$path;
//             echo '<br>';
            
//             // Usage of is method
//             $method = $request->isMethod('get') ? "GET" : "POST";
//             echo 'GET or POST Method: '.$method;
//             echo '<br>';
            
//             // Usage of url method
//             $url = $request->url();
//             echo 'URL method: '.$url;
//             echo '<br>';
            
//             $firstName = $request->input('firstname');
//             $lastName = $request->input('lastname');
//             echo "Your name is: " . $firstName . " " . $lastName . "<br>";
           


<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CustomerModel;
use App\Services\Business\SecurityService;

class CustomerController extends Controller
{
    

    
        public function index(Request $request)
        {
            
            //this is from the next step d
            //Create a UserModel with username and password   
            $customerData = new CustomerModel(request()->get('firstName'), request()->get('lastName'));
            
            //testing
            $nextID = 0;
            
            
            //instantiate the business Logic Layer 
            //$serviceCustomer = new SecurityService();
            //pass customerData to the business layer
            //$isValid = $serviceCustomer->addCustomer($customerData);
            
            //Determine which view to display
//             if($isValid)
//             {
//                 echo("Customer Data Added Succesfully ");
             
//             }
//             else{
//                 echo("Customer Data was not added");
//             }
                 return redirect('neworder')->with('nextID', $nextID)->with('firstName',request()->get('firstName'))->with('lastName',request()->get('lastName'));
                 
                 

            
        }
        //validation function added for Activity3
        public function validateForm(Request $request)
        {
            //Set up data validation for our login form
            $rules = ['username'=>'Required|bewtween:4,10|Alpha',
                'password'=>'Required|Between:4,10'];
            //Run data validation rules
            $this->validator($request, $rules);
        }
        

}
            

            
            
            
            
//             $formValues = $request->all();
//             $userName = $request->get('username');
            
//             // Usage of path method
//             $path = $request->path();
//             echo 'Path Method: '.$path;
//             echo '<br>';
            
//             // Usage of is method
//             $method = $request->isMethod('get') ? "GET" : "POST";
//             echo 'GET or POST Method: '.$method;
//             echo '<br>';
            
//             // Usage of url method
//             $url = $request->url();
//             echo 'URL method: '.$url;
//             echo '<br>';
            
//             $firstName = $request->input('firstname');
//             $lastName = $request->input('lastname');
//             echo "Your name is: " . $firstName . " " . $lastName . "<br>";
           


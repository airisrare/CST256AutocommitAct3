
<html>
<title>User Login</title>
<body>
<div>

<form action = "dologin" method = "post">
{{csrf_field() }}
<div class= "demo-table">
<div class = "form-head">Login</div>

<div class="form-column">

	<div>
	<label for="username">UserName</label><span id="user_info" class="error-info"></span>
	</div>
	
	<div>
<input name="username" id ="username" type="text" class="demo-input-box">
	</div>
	<?php echo $errors->first('username')?>

<div class="form-column">
	<div>
	<label for="password">Password</label><span id="password_info" class="error-info"></span>
</div>
<div>
<input name="password" id ="password" type="text" class="demo-input-box">
</div>
<?php echo $errors->first('password')?>

<div>
<input type="submit" class="btnLogin">
</div>
</div>
</div>
</div>
</form>

</div>

</body>

</html>
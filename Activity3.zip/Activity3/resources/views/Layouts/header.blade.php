<html><head>
<center>
<h2>Welcome to activity 1</h2>
</center>

</head></html>
<?php
namespace App\Services\Data;

use App\User;

class SecurityDAO {
    
    public function findByUser($username,$password){
        
         }
    
}
   
    



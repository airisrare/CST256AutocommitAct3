<?php
?>

<div align="center">@yield('content')</div>

<html>
<head><meta name="csrf-token" content="{{ csrf_token() }}"></head>
<title>Add Numbers</title>
<body>
	<div>

		<form action="addcustomer" method="post">
			{{csrf_field() }}


			<div class="demo-table">
				<div class="form-head">Add Numbers</div>

				<div class="form-column">

					<div>
						<label for="firstName">FirstName</label><span id="firstname_info"
							class="error-info"></span>
					</div>

					<div>
						<input name="firstName" id="firstName" type="text"
							class="demo-input-box">

					</div>

					<div class="form-column">
						<div>
							<label for="lastName">LastName</label><span id="lastname_info"
								class="error-info"></span>
						</div>
						<div>
							<input name="lastName" id="lastName" type="text"
								class="demo-input-box">

						</div>

						<div>
							<input type="submit" class="btnLogin">
						</div>
					</div>
		
		</form>

	</div>
</body>

</html>